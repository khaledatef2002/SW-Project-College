

<?php $__env->startSection('title', 'Courses'); ?>

<?php $__env->startSection('course-active', 'active'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <!-- Add Button -->
    <div class="mb-3 text-end">
        <a href="<?php echo e(route('courses.create')); ?>"><button type="button" class="btn btn-primary">Add New</button></a>
    </div>
    <!-- Table to show data -->
    <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
    <table class="table bg-white text-center">
        <thead class="bg-dark text-white">
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Course Name</th>
                <th scope="col">Semester</th>
                <th scope="col">Doctor</th>
                <th scope="col">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if(count($courses) > 0): ?>
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($course->id); ?></th>
                        <td><?php echo e($course->name); ?></td>
                        <td><?php echo e($course->semester->semester_name); ?></td>
                        <td><?php echo e($course->doctor->name ?? ''); ?></td>
                        <td>
                            <a href="<?php echo e(route('courses.edit', ['course' => $course])); ?>"><button type="button" class="btn btn-primary">Edit</button></a>
                            <form class="d-inline-block" action="<?php echo e(route('courses.delete', ['course'=> $course])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr class="text-center">
                    <td colspan="6">No Data Found</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <?php echo e($courses->render('pagination::bootstrap-5')); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sw\resources\views/courses.blade.php ENDPATH**/ ?>