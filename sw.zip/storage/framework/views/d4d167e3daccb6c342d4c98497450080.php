<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid justify-content-center">
        <a class="navbar-brand" href="#">University System</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link <?php echo $__env->yieldContent('home-active'); ?>" href="<?php echo e(route('home')); ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $__env->yieldContent('course-active'); ?>" href="<?php echo e(route('courses.index')); ?>">Courses</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $__env->yieldContent('doctor-active'); ?>" href="<?php echo e(route('doctors.index')); ?>">Doctors</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $__env->yieldContent('semesters-active'); ?>" href="<?php echo e(route('semesters.index')); ?>">Semesters</a>
                </li>
            </ul>
        </div>
    </div>
</nav><?php /**PATH C:\laragon\www\sw\resources\views/partials/navbar.blade.php ENDPATH**/ ?>