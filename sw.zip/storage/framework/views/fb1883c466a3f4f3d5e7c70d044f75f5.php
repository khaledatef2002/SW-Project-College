

<?php $__env->startSection('title', 'Doctors'); ?>

<?php $__env->startSection('doctor-active', 'active'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <!-- Add Button -->
    <div class="mb-3 text-end">
        <a href="<?php echo e(route('doctors.create')); ?>"><button type="button" class="btn btn-primary">Add New</button></a>
    </div>
    <!-- Table to show data -->
    <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
    <table class="table bg-white text-center">
        <thead class="bg-dark text-white">
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Doctor Name</th>
                <th scope="col">Doctor Email</th>
                <th scope="col">Doctor Salary</th>
                <th scope="col">Course</th>
                <th scope="col">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if(count($doctors) > 0): ?>
                <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($doctor->id); ?></th>
                        <td><?php echo e($doctor->name); ?></td>
                        <td><?php echo e($doctor->email); ?></td>
                        <td><?php echo e($doctor->salary); ?>$</td>
                        <td><?php echo e(count($doctor->course)); ?></td>
                        <td>
                            <a href="<?php echo e(route('doctors.edit', ['doctor' => $doctor])); ?>"><button type="button" class="btn btn-primary">Edit</button></a>
                            <form class="d-inline-block" action="<?php echo e(route('doctors.delete', ['doctor'=> $doctor])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr class="text-center">
                    <td colspan="6">No Data Found</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <?php echo e($doctors->render('pagination::bootstrap-5')); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sw\resources\views/doctors.blade.php ENDPATH**/ ?>